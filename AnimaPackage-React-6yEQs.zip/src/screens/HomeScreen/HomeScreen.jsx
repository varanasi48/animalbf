import React from "react";
import { Home } from "../../components/Home";
import "./style.css";

export const HomeScreen = () => {
  return <Home className="home-instance" />;
};
