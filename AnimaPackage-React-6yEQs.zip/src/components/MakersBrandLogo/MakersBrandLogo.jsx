/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const MakersBrandLogo = ({ type, className }) => {
  return (
    <div className={`MAKERS-BRAND-LOGO ${type} ${className}`}>
      <div className="making-it-logo">
        {type === "logo" && (
          <>
            <div className="div">
              <div className="overlap-group">
                <div className="rectangle" />
                <div className="rectangle-2" />
                <div className="rectangle-3" />
              </div>
            </div>
            <div className="text-wrapper">Logo</div>
          </>
        )}

        {type === "icon" && (
          <div className="overlap-group-wrapper">
            <div className="div">
              <div className="rectangle" />
              <div className="rectangle-2" />
              <div className="rectangle-3" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

MakersBrandLogo.propTypes = {
  type: PropTypes.oneOf(["icon", "logo"]),
};
