import { MakersBrandLogo } from ".";

export default {
  title: "Components/MakersBrandLogo",
  component: MakersBrandLogo,
  argTypes: {
    type: {
      options: ["icon", "logo"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    type: "icon",
    className: {},
  },
};
