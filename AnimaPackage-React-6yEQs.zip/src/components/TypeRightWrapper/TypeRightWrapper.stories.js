import { TypeRightWrapper } from ".";

export default {
  title: "Components/TypeRightWrapper",
  component: TypeRightWrapper,
  argTypes: {
    type: {
      options: ["center", "right", "left"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    type: "center",
    MAKERSNavigationText: "Nav Item",
    MAKERSNavigationText1: "Nav Item",
    MAKERSNavigationText2: "Nav Item",
    MAKERSNavigationText3: "Nav Item",
    MAKERSButtonText: "Button",
  },
};
