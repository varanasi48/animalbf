/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { MakersBrandLogo } from "../MakersBrandLogo";
import { MakersButton } from "../MakersButton";
import { MakersNavigation } from "../MakersNavigation";
import "./style.css";

export const TypeRightWrapper = ({
  type,
  MAKERSNavigationText = "Nav Item",
  MAKERSNavigationText1 = "Nav Item",
  MAKERSNavigationText2 = "Nav Item",
  MAKERSNavigationText3 = "Nav Item",
  MAKERSButtonText = "Button",
  to,
}) => {
  return (
    <div className="type-right-wrapper">
      <div className="container">
        {type === "center" && (
          <div className="MAKERS-BRAND-LOGO-wrapper">
            <MakersBrandLogo className="instance-node" type="logo" />
          </div>
        )}

        <div className={`center-2 ${type}`}>
          {type === "center" && (
            <div className="links">
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
            </div>
          )}

          {["left", "right"].includes(type) && <MakersBrandLogo className="instance-node" type="logo" />}

          {type === "left" && (
            <div className="links-2">
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
              <MakersNavigation className="instance-node" stateProp="default" text="Nav Item" />
            </div>
          )}
        </div>
        {type === "center" && (
          <div className="MAKERS-BUTTON-wrapper">
            <MakersButton className="instance-node" stateProp="default" text="Button" type="primary" />
          </div>
        )}

        {["left", "right"].includes(type) && (
          <div className="right-2">
            {type === "right" && (
              <div className="links-3">
                <MakersNavigation className="instance-node" stateProp="default" text={MAKERSNavigationText} to={to} />
                <MakersNavigation className="instance-node" stateProp="default" text={MAKERSNavigationText1} />
                <MakersNavigation className="instance-node" stateProp="default" text={MAKERSNavigationText2} />
                <MakersNavigation className="instance-node" stateProp="default" text={MAKERSNavigationText3} />
              </div>
            )}

            <MakersButton
              className="instance-node"
              stateProp="default"
              text={type === "left" ? "Button" : MAKERSButtonText}
              type="primary"
            />
          </div>
        )}
      </div>
    </div>
  );
};

TypeRightWrapper.propTypes = {
  type: PropTypes.oneOf(["center", "right", "left"]),
  MAKERSNavigationText: PropTypes.string,
  MAKERSNavigationText1: PropTypes.string,
  MAKERSNavigationText2: PropTypes.string,
  MAKERSNavigationText3: PropTypes.string,
  MAKERSButtonText: PropTypes.string,
  to: PropTypes.string,
};
