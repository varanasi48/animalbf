/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { TypeRightWrapper } from "../TypeRightWrapper";
import "./style.css";

export const Home = ({ className }) => {
  return (
    <div className={`home ${className}`}>
      <div className="life-is-beautiful">Life is Beautiful</div>
      <div className="untitled-site-page">
        <TypeRightWrapper
          MAKERSButtonText="Login"
          MAKERSNavigationText="Home"
          MAKERSNavigationText1="Plans"
          MAKERSNavigationText2="Team"
          MAKERSNavigationText3="Contact Us"
          to="/home"
          type="right"
        />
      </div>
    </div>
  );
};
