import { Home } from ".";

export default {
  title: "Components/Home",
  component: Home,
};

export const Default = {
  args: {
    className: {},
  },
};
