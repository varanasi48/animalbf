import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { HomeScreen } from "./screens/HomeScreen";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <HomeScreen />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
